var user={name:null,
regNumber:null,
phoneNumber:null,
emailAddress:null,
currentYear:1.1,
privilege:"user"
};

var validationStatus=document.getElementById("validationStatus");

var loader2=document.getElementById("loader2");

var nameInput=document.getElementById("name");
var emailInput=document.getElementById("email");
var phoneInput=document.getElementById("phone");
var regInput=document.getElementById("regno");
var yearInput=document.getElementById("year");

var password1Input=document.getElementById("pass1");
var password2Input=document.getElementById("pass2");

function registerUser(){
  validationStatus.style.display="none";
  loader2.style.display="block";
  
  var name=nameInput.value;
  var email=emailInput.value;
  var phone=phoneInput.value;
  var year=yearInput.value;
  var regNumber=regInput.value;
  var pass1=password1Input.value;
  var pass2=password2Input.value;
  
  if (name==null || name=="" ||name==undefined) {
    validationStatus.innerHTML="The username cannot be empty";
    validationStatus.style.display="block";
    return;
  }
  
  var specialChars=['@','#','$','_','&',':',';','!','?',',','-','+','(',')','/','~'];
  
  for (var i in specialChars) {
    if(i==name){
      validationStatus.innerHTML="The username cannot contain special symbols";
    validationStatus.style.display="block";
    return;
    }
  }

  if(phone.length!=10){
    validationStatus.innerHTML="The phoneNumber can only be 10 numbers";
    validationStatus.style.display="block";
    return;
  }
  
  if(regno.length>13 ||regno.length<10){
    validationStatus.innerHTML="The Reg Number is invalid";
    validationStatus.style.display="block";
    return;
  }
  
  if(pass1=="" || pass1!=pass2){
    validationStatus.innerHTML="Passwords Don't match";
    validationStatus.style.display="block";
    return;
  }
  
  $.ajax({
    url:"auth.php",
    method:"POST",
    data:{
      "name":name,
      "phone": phone,
      "email":email,
      "regno":regno,
      "year":year,
      "pass":pass1
    },
    success: function(data){
    var response= JSON.parse(data);
  if(response.success==true){
    window.location.replace('index.html');
    
  } else {
    validationStatus.innerHTML=response.message;
    validationStatus.style.display="block";
    loader2.style.display="none";
    }}
    
  });
  
  
}
